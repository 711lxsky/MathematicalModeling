function [res] = funTwo(x)
res = -293.098+0.002*x*x;
end

