function [res]=funThr(x)
res = -283.373+0.0018744*x*x;
end

