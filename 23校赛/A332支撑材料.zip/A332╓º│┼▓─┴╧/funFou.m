function [res] = funFou(x)
res = -288.2355+0.00195*x*x;
end

